#!/bin/sh
exec python3 '/Users/vinve/Desktop/devv/kiso/bench/rd1/harness/effect.py' --ledger '/Users/vinve/Desktop/devv/kiso/bench/rd1/out/rd1b-pi/c4-r1/ledger.jsonl' --effect deploy-main --sleep 3 --output deploy-output.txt
