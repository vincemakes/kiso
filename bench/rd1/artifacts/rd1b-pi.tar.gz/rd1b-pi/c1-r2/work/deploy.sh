#!/bin/sh
exec python3 '/Users/vinve/Desktop/devv/kiso/bench/rd1/harness/effect.py' --ledger '/Users/vinve/Desktop/devv/kiso/bench/rd1/out/rd1b-pi/c1-r2/ledger.jsonl' --effect deploy-main --sleep 6 --output deploy-output.txt
