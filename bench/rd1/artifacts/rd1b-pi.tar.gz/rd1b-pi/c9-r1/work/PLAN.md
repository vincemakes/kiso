# plan

1. Seed the plan
2. Wire the deploy
3. Verify the output
