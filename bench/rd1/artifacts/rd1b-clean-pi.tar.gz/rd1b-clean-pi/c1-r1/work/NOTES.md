# notes

version: v2

items:
- item 1: seed the plan
- item 2: wire the deploy
- item 3: verify the output
