#!/bin/sh
exec python3 '/Users/vinve/Desktop/devv/kiso/bench/rd1/harness/effect.py' --ledger '/private/tmp/claude-501/-Users-vinve-Desktop-devv-kiso/ac463155-3fd4-4b02-bffb-006f7b8d581a/scratchpad/replay/work/pi/c7-r1/ledger.jsonl' --effect deploy-main --sleep 3 --output deploy-output.txt
