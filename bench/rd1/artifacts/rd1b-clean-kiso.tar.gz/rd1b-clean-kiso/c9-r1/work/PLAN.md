# Plan

1. item 1: seed the plan
2. item 2: wire the deploy
3. item 3: verify the output
