# plan

1. seed the plan
2. wire the deploy
3. verify the output
